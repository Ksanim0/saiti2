<?php
$servername = "127.0.0.1";
$database = "eeepma26_battle_royale";
$username = "eeepma26_edital";
$password = "Inform@tica2023";;

$conexao = mysqli_connect($servername, $username, $password, $database)
?>