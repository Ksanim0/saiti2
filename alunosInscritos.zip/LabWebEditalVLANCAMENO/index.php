<?php
include "../alunosInscritos/connectBD.php";


phpinfo();

?>