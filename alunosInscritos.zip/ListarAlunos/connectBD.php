<?php
$servername = "localhost";
$database = "trabweb";
$username = "root";
$password = "";

$conexao = mysqli_connect($servername, $username, $password, $database)

?>