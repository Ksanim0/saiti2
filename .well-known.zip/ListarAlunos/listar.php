<?php
	include "../alunosInscritos/connectBD.php";
	$listarSQL = mysqli_query($conexao, "SELECT * FROM  aluno");

?>